# Crafter Double DQN + n-step Agent

Hand-written Double DQN with 3-step returns for the Crafter environment (Kilian Calmets & Mathis Pezet).

## Setup and Reproduction

```bash
pip install -r requirements.txt
python train.py            # default best config: Double DQN, n-step=3, 1,000,000 steps, seed 1
python train.py --seed 2   # second training seed
python evaluate.py --checkpoint runs/double_nstep_seed1/checkpoint_1000000.pt --episodes 50 --seed 7001 --out runs/eval_seed1
python evaluate.py --checkpoint runs/double_nstep_seed2/checkpoint_1000000.pt --episodes 50 --seed 7001 --out runs/eval_seed2
python evaluate.py --episodes 50 --seed 7001 --out runs/random_repro
python report.py runs/eval_seed1 runs/eval_seed2 --out runs/report_repro.json
```

To regenerate slide figures from recorded runs:

```bash
python figures.py --train runs/double_nstep_1m_g4_seed1 runs/double_nstep_1m_g4_seed2 --eval runs/final_1m_g4_seed1 runs/final_1m_g4_seed2 --eval-curve runs/val_300k_g4_seed1 runs/val_300k_g4_seed2 runs/val_500k_g4_seed1 runs/val_500k_g4_seed2 runs/val_1m_g4_seed1 runs/val_1m_g4_seed2 --scalars runs/double_nstep_1m_g4_seed1 runs/double_nstep_1m_g4_seed2 --random runs/random_seed7001 --max-step 1000000 --out figures
```

## Included Files

- `train.py`: environment loop, epsilon-greedy policy, Double DQN optimization, checkpointing (`argparse` defaults run the selected 1M-step configuration).
- `agent/network.py`, `agent/replay.py`: 3-layer CNN Q-network, uint8 uniform replay buffer, and variable-horizon n-step accumulator.
- `evaluate.py`, `metrics.py`, `report.py`, `figures.py`: greedy and random evaluation, Crafter geometric score calculation, multi-seed aggregation, and slide figure generation.
- `figures/`: slide figures (`training_reward.png`, `training_diagnostics.png`, `evaluation_curve.png`, `evaluation_reward.png`, `achievements.png`, `crafter_observation.png`).
- `runs/`: training configs and 1k-step scalar logs (`scalars.csv`), final 50-episode greedy & random evaluations (`final_1m_g4_seed*/`, `random_seed7001/`, `final_report.json`), and behavior trace (`behavior_1m_seed1/trace.jsonl`). Checkpoints are excluded.

## Measured Results (2 training seeds, 1M steps, greedy eval on seeds 7001-7050)

- **Agent mean (2 seeds):** episodic reward **4.15 +/- 0.16**, Crafter score **4.14 +/- 0.60 %** (mean episode length **191.0 +/- 1.2** steps).
- **Random baseline (same 50 episodes):** episodic reward **1.32**, Crafter score **1.23 %** (mean length **170.2** steps).
